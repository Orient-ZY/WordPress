<div class="mainbottom">
	<ul>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('widget_single_bottom') ) : ?><?php endif; ?>
	</ul>
</div>