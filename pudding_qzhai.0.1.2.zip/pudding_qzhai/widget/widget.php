<?php
include('widget-author.php');
include('widget-img.php');